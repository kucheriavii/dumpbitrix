<?
$MESS ['T_DEFAULT_DESC_NAME'] = "Общий шаблон";
$MESS ['T_DEFAULT_DESC_DESC'] = "Общие включаемые файлы, header.php и footer.php по умолчанию.";
?>